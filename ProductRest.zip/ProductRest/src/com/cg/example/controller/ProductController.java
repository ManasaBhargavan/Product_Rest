package com.cg.example.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.example.beans.Product;
import com.cg.example.service.IProductService;


@Path("/products")
public class ProductController {
	
	IProductService productservice;
	
	@GET
	@Path("/list")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts(){
		for(int i = 0 ; i< 10 ; i++){
			System.out.println("Entered");
		
			}
		List<Product> listOfProducts = productservice.getAllProducts();
		return listOfProducts;
	}
	
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductById(@PathParam("id") int id){
		return productservice.getProduct(id);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("txtid")int txtid,@FormParam("txtname")String txtname,@FormParam("txtprice")double txtprice){
		Product product=new Product();
		product.setProductId(txtid);
		product.setProductName(txtname);
		product.setProductPrice(txtprice);
		return productservice.addProduct(product);
	}
	
	
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Product deleteProduct(@FormParam("txtid")int id){
		Product product=productservice.deleteProduct(id);
		if(product!=null){
			return product;
		}
		else{
			return new Product();
		}
	}

}
