package com.cg.example.service;

import java.util.List;

import com.cg.example.beans.Product;
import com.cg.example.dao.IProductDAO;
import com.cg.example.dao.ProductDaoImpl;

public class ProductService implements IProductService {

	IProductDAO dao;

	@Override
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	@Override
	public Product getProduct(int id) {
		return dao.getProduct(id);
	}

	@Override
	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	@Override
	public Product deleteProduct(int id) {
		return dao.deleteProduct(id);
	}

}
