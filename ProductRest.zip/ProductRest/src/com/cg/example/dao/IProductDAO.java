package com.cg.example.dao;

import java.util.List;

import com.cg.example.beans.Product;

public interface IProductDAO {
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product product);
	public Product deleteProduct(int id);

}
