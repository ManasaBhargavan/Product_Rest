package com.cg.example.staticdb;

import java.util.HashMap;

import com.cg.example.beans.Product;

public class ProductDB {

static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product indiaCountry = new Product(1, "India", 10000);
			Product chinaCountry = new Product(4, "China", 20000);
			Product nepalCountry = new Product(3, "Nepal", 8000);
			Product bhutanCountry = new Product(2, "Bhutan", 7000);

			productIdMap.put(1, indiaCountry);
			productIdMap.put(4, chinaCountry);
			productIdMap.put(3, nepalCountry);
			productIdMap.put(2, bhutanCountry);
		}
}

	public static HashMap<Integer, Product> getProductIdMap() {
		// TODO Auto-generated method stub
		return productIdMap;
	}
}